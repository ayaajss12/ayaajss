// script.js
const password = 'rafilacalvita'; // Contraseña de acceso
const loginBtn = document.getElementById('login-btn');
const passwordInput = document.getElementById('password');
const content = document.querySelector('.content');
const chuletaText = document.getElementById('chuleta-text');
const chuletaImage = document.getElementById('chuleta-image');
const saveChuletaBtn = document.getElementById('save-chuleta');
const chuletaList = document.getElementById('chuleta-list');
const userNameInput = document.getElementById('user-name'); // Campo para nombre
const attemptsMessage = document.getElementById('attempts'); // Mensaje de intentos

let attempts = 3; // Número de intentos permitidos
let lockoutTime = null; // Tiempo de bloqueo
const lockoutDuration = 60 * 60 * 1000; // 1 hora en milisegundos

function checkLockout() {
    if (lockoutTime) {
        const currentTime = Date.now();
        if (currentTime < lockoutTime) {
            const timeLeft = Math.ceil((lockoutTime - currentTime) / 1000);
            attemptsMessage.textContent = `Has agotado todos los intentos. Intenta de nuevo en ${timeLeft} segundos.`;
            loginBtn.disabled = true; // Deshabilitar el botón mientras está bloqueado
            return true;
        } else {
            lockoutTime = null; // Resetear el tiempo de bloqueo
            attempts = 3; // Reiniciar intentos
            attemptsMessage.textContent = '';
        }
    }
    return false;
}

loginBtn.addEventListener('click', () => {
    if (checkLockout()) return; // Comprobar si está bloqueado

    if (passwordInput.value === password) {
        content.style.display = 'block'; // Mostrar contenido después de iniciar sesión
        document.querySelector('.login-container').style.display = 'none'; // Ocultar la sección de login
        attempts = 3; // Reiniciar intentos
        attemptsMessage.textContent = ''; // Limpiar mensaje de intentos
    } else {
        attempts--; // Reducir el número de intentos
        attemptsMessage.textContent = `Contraseña incorrecta. Te quedan ${attempts} intento(s).`;
        if (attempts === 0) {
            lockoutTime = Date.now() + lockoutDuration; // Establecer tiempo de bloqueo
            loginBtn.disabled = true; // Deshabilitar el botón después de 3 intentos
            attemptsMessage.textContent = 'Has agotado todos los intentos. Intenta más tarde.';
        }
    }
});

saveChuletaBtn.addEventListener('click', () => {
    const chuletaValue = chuletaText.value.trim();
    const userName = userNameInput.value.trim(); // Obtener el nombre del usuario
    const imageFile = chuletaImage.files[0];
    
    if (chuletaValue === '' || userName === '') {
        alert('Por favor, completa tu nombre y escribe tu chuleta antes de guardar.');
        return;
    }

    const date = new Date();
    const formattedDate = date.toLocaleDateString();
    const formattedTime = date.toLocaleTimeString();

    const chuletaItem = document.createElement('li');
    chuletaItem.innerHTML = `
        <strong>Nombre:</strong> ${userName} <br>
        <strong>Chuleta:</strong> ${chuletaValue} <br>
        <strong>Fecha:</strong> ${formattedDate} <br>
        <strong>Hora:</strong> ${formattedTime}
    `;

    // Si hay una imagen, se puede mostrar
    if (imageFile) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.createElement('img');
            img.src = e.target.result;
            img.style.width = '100px'; // Tamaño de la imagen
            img.style.height = '100px';
            chuletaItem.appendChild(img);
        }
        reader.readAsDataURL(imageFile);
    }

    chuletaList.appendChild(chuletaItem);
    chuletaText.value = ''; // Limpiar el área de texto
    chuletaImage.value = ''; // Limpiar el input de archivo
    userNameInput.value = ''; // Limpiar el campo de nombre
});
